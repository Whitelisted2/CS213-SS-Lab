main webpage is included in .txt AND .html formats.

Notepad++ was used as a text editor for this assignment,
with the help of XAMPP's Apache and mySQL apps as well.

Year accepts integer values only. Negative values may be considered
as Before Common Era (BCE), so the only constraint is that it must be
an INTEGER.